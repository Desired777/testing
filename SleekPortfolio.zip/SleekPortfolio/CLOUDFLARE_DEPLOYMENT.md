# Deploying to Cloudflare Pages

This portfolio is fully compatible with Cloudflare Pages. Follow these steps to deploy:

## Quick Deploy

1. **Push to GitHub**
   - Create a new GitHub repository
   - Push this code to your repository

2. **Connect to Cloudflare Pages**
   - Go to [Cloudflare Pages](https://pages.cloudflare.com/)
   - Click "Create a project"
   - Connect your GitHub account
   - Select your repository

3. **Configure Build Settings**
   - **Framework preset**: None (or Vite)
   - **Build command**: `npm run build`
   - **Build output directory**: `dist`
   - **Root directory**: (leave blank or `/`)

4. **Environment Variables** (if needed)
   - No environment variables are required for basic deployment
   - The Web3Forms contact form will work automatically

5. **Deploy**
   - Click "Save and Deploy"
   - Your site will be live in minutes!

## Build Configuration

The project includes:
- ✅ `vite build` command in package.json
- ✅ `_redirects` file for SPA routing in `client/public/`
- ✅ Optimized production build settings
- ✅ Static asset handling

## Custom Domain (Optional)

1. In your Cloudflare Pages project settings
2. Go to "Custom domains"
3. Add your domain
4. Follow DNS configuration instructions

## Notes

- The time and location features work client-side using browser APIs
- Contact form uses Web3Forms API (already configured)
- Dark/light theme preference is saved in browser localStorage
- All animations and effects work perfectly on Cloudflare Pages
- The site is fully static after build - no server required!

## Performance

Cloudflare Pages provides:
- ✅ Global CDN distribution
- ✅ Automatic HTTPS
- ✅ Instant cache invalidation
- ✅ Unlimited bandwidth
- ✅ DDoS protection
