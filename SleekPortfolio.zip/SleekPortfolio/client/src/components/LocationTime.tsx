import { useState, useEffect } from "react";
import { MapPin, Clock } from "lucide-react";

export function LocationTime() {
  const [location, setLocation] = useState({ city: "Loading...", country: "Loading..." });
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    fetch("https://ipapi.co/json/")
      .then((res) => res.json())
      .then((data) => {
        setLocation({
          city: data.city || "Unknown",
          country: data.country_name || "Unknown",
        });
      })
      .catch(() => {
        setLocation({ city: "Unknown", country: "Unknown" });
      });

    const interval = setInterval(() => {
      setTime(new Date());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="mt-8 pt-8 border-t border-card-border space-y-3">
      <div className="flex items-center gap-2 text-muted-foreground">
        <MapPin className="w-4 h-4" />
        <span className="text-sm" data-testid="text-location">
          {location.city}, {location.country}
        </span>
      </div>
      <div className="flex items-center gap-2 text-muted-foreground">
        <Clock className="w-4 h-4" />
        <span className="text-sm font-mono" data-testid="text-time">
          {time.toLocaleTimeString()}
        </span>
      </div>
    </div>
  );
}
