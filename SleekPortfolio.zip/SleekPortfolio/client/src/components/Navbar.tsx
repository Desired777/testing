import { useState, useEffect } from "react";
import { Globe, Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "./ThemeProvider";

export function Navbar() {
  const { theme, setTheme } = useTheme();
  const [text, setText] = useState("");
  const fullText = "Desired777";
  const [isTypingComplete, setIsTypingComplete] = useState(false);
  const [isGlobeAnimating, setIsGlobeAnimating] = useState(false);

  useEffect(() => {
    if (text.length < fullText.length) {
      const timeout = setTimeout(() => {
        setText(fullText.slice(0, text.length + 1));
      }, 150);
      return () => clearTimeout(timeout);
    } else {
      setIsTypingComplete(true);
    }
  }, [text]);

  const handleGlobeClick = () => {
    setIsGlobeAnimating(true);
    setTimeout(() => setIsGlobeAnimating(false), 600);
    scrollToSection("contact");
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <nav className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-[95%] max-w-6xl">
      <div className="bg-card/80 backdrop-blur-xl border-2 border-white/30 rounded-2xl shadow-[0_0_100px_rgba(255,255,255,0.4),0_0_50px_rgba(255,255,255,0.3)] hover:shadow-[0_0_130px_rgba(255,255,255,0.55),0_0_70px_rgba(255,255,255,0.45)] transition-all duration-500">
        <div className="flex items-center justify-between px-6 py-3">
          <div className="flex items-center gap-2">
            <button 
              onClick={handleGlobeClick}
              className={`hover-elevate active-elevate-2 rounded-full p-1 transition-all ${
                isGlobeAnimating ? 'animate-spin' : ''
              }`}
              data-testid="button-globe-icon"
            >
              <Globe 
                className={`w-5 h-5 text-foreground transition-all duration-300 ${
                  isGlobeAnimating ? 'scale-110' : ''
                }`} 
                data-testid="icon-globe" 
              />
            </button>
            <span 
              className="text-lg font-semibold text-foreground"
              data-testid="text-website-name"
            >
              {text}
              {!isTypingComplete && (
                <span className="animate-pulse">|</span>
              )}
            </span>
          </div>

          <div className="hidden md:flex items-center gap-1">
            {["About", "Skills", "Experience", "Projects", "Contact"].map((item) => (
              <Button
                key={item}
                variant="ghost"
                size="sm"
                onClick={() => scrollToSection(item.toLowerCase())}
                className="text-muted-foreground hover:text-foreground"
                data-testid={`button-nav-${item.toLowerCase()}`}
              >
                {item}
              </Button>
            ))}
          </div>

          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="relative overflow-visible"
            data-testid="button-theme-toggle"
          >
            <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
            <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
          </Button>
        </div>
      </div>
    </nav>
  );
}
