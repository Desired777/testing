import { motion } from "framer-motion";
import { Users, Code, Gamepad2 } from "lucide-react";

const skills = [
  {
    icon: Users,
    title: "Community Moderation",
    description: "I have been moderating many games and Discord servers for over 3+ years and have exceeded expectations.",
  },
  {
    icon: Code,
    title: "LUA & Fullstack Development",
    description: "Experienced with LUA, creating and collaborating with multiple groups and studios including Axiom Interactive. Moving away from Roblox Studio, I've made several web applications from back-end to front-end, including this portfolio.",
  },
  {
    icon: Gamepad2,
    title: "Game Development",
    description: "I've been designing and creating games for a while. One of my favorite projects is an upcoming game within Axiom Interactive.",
  },
];

export function Skills() {
  return (
    <section id="skills" className="min-h-screen flex items-center justify-center px-4 py-20">
      <div className="max-w-6xl w-full">
        <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-12 text-center" data-testid="text-skills-heading">
          Skills
        </h2>
        <div className="grid md:grid-cols-3 gap-6">
          {skills.map((skill, index) => (
            <motion.div
              key={skill.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="bg-card/50 backdrop-blur-xl border-2 border-white/30 rounded-2xl shadow-[0_0_100px_rgba(255,255,255,0.4),0_0_50px_rgba(255,255,255,0.3)] hover:shadow-[0_0_150px_rgba(255,255,255,0.6),0_0_80px_rgba(255,255,255,0.5)] hover:scale-[1.05] transition-all duration-500"
              data-testid={`card-skill-${index}`}
            >
              <div className="flex items-center gap-2 px-4 py-3 border-b border-white/10">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
              </div>
              <div className="p-6">
                <skill.icon className="w-12 h-12 mb-4 text-foreground" data-testid={`icon-skill-${index}`} />
                <h3 className="text-xl font-semibold text-foreground mb-3" data-testid={`text-skill-title-${index}`}>
                  {skill.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed" data-testid={`text-skill-description-${index}`}>
                  {skill.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
