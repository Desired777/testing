import { motion } from "framer-motion";
import { ExternalLink } from "lucide-react";

const projects = [
  {
    title: "Axiom Interactive",
    description: "A new and upcoming development studio in Roblox.",
  },
  {
    title: "This Portfolio",
    description: "The website you are currently viewing.",
  },
];

export function Projects() {
  return (
    <section id="projects" className="min-h-screen flex items-center justify-center px-4 py-20">
      <div className="max-w-5xl w-full">
        <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-12 text-center" data-testid="text-projects-heading">
          Projects
        </h2>
        <div className="grid md:grid-cols-2 gap-6">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-card/50 backdrop-blur-xl border-2 border-white/30 rounded-2xl shadow-[0_0_100px_rgba(255,255,255,0.4),0_0_50px_rgba(255,255,255,0.3)] hover:shadow-[0_0_150px_rgba(255,255,255,0.6),0_0_80px_rgba(255,255,255,0.5)] hover:scale-[1.03] hover:-translate-y-2 transition-all duration-500 group cursor-pointer"
              data-testid={`card-project-${index}`}
            >
              <div className="flex items-center gap-2 px-4 py-3 border-b border-white/10">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
              </div>
              <div className="p-8">
                <div className="flex items-start justify-between mb-4">
                  <h3 className="text-2xl font-semibold text-foreground" data-testid={`text-project-title-${index}`}>
                    {project.title}
                  </h3>
                  <ExternalLink className="w-5 h-5 text-muted-foreground group-hover:text-foreground transition-colors" />
                </div>
                <p className="text-foreground leading-relaxed" data-testid={`text-project-description-${index}`}>
                  {project.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
