import { motion } from "framer-motion";

const experiences = [
  {
    year: "2022–2024",
    role: "Back-End & LUA Freelance",
    description: "Did some freelance for a while as a side hustle until I started applying for groups and studios and successfully got in many.",
  },
  {
    year: "2023–2024",
    role: "Crunchy Orc – Employee",
    description: "Helped promote, boost sales, and managed to get several influencers to play their games and upload them on their platform.",
  },
];

export function Experience() {
  return (
    <section id="experience" className="min-h-screen flex items-center justify-center px-4 py-20">
      <div className="max-w-4xl w-full">
        <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-12 text-center" data-testid="text-experience-heading">
          Experience
        </h2>
        <div className="space-y-8">
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="relative pl-8 border-l-2 border-card-border"
              data-testid={`card-experience-${index}`}
            >
              <div className="absolute -left-2 top-0 w-4 h-4 rounded-full bg-foreground"></div>
              <div className="bg-card/50 backdrop-blur-xl border-2 border-white/30 rounded-2xl shadow-[0_0_100px_rgba(255,255,255,0.4),0_0_50px_rgba(255,255,255,0.3)] hover:shadow-[0_0_150px_rgba(255,255,255,0.6),0_0_80px_rgba(255,255,255,0.5)] hover:scale-[1.02] hover:-translate-y-1 transition-all duration-500">
                <div className="flex items-center gap-2 px-4 py-3 border-b border-white/10">
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                </div>
                <div className="p-6">
                  <div className="text-sm text-muted-foreground mb-1" data-testid={`text-experience-year-${index}`}>
                    {exp.year}
                  </div>
                  <h3 className="text-2xl font-semibold text-foreground mb-3" data-testid={`text-experience-role-${index}`}>
                    {exp.role}
                  </h3>
                  <p className="text-foreground leading-relaxed" data-testid={`text-experience-description-${index}`}>
                    {exp.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center text-muted-foreground mt-12 italic"
          data-testid="text-experience-footer"
        >
          Still learning, more to be added here soon.
        </motion.p>
      </div>
    </section>
  );
}
