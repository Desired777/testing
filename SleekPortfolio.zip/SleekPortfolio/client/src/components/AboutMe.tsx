import { motion } from "framer-motion";

export function AboutMe() {
  return (
    <section id="about" className="min-h-screen flex items-center justify-center px-4 py-20">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="max-w-3xl w-full"
      >
        <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-8 text-center" data-testid="text-about-heading">
          About Me
        </h2>
        <div className="bg-card/50 backdrop-blur-xl border-2 border-white/30 rounded-2xl shadow-[0_0_100px_rgba(255,255,255,0.4),0_0_50px_rgba(255,255,255,0.3)] hover:shadow-[0_0_150px_rgba(255,255,255,0.6),0_0_80px_rgba(255,255,255,0.5)] hover:scale-[1.02] hover:-translate-y-2 transition-all duration-500">
          <div className="flex items-center gap-2 px-4 py-3 border-b border-white/10">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
          </div>
          <div className="p-8 md:p-12">
            <p className="text-lg md:text-xl text-foreground leading-relaxed" data-testid="text-about-content">
              Hello, I am <span className="font-semibold">Desired777</span>. I specialize in{" "}
              <span className="font-semibold">LUA scripting</span>,{" "}
              <span className="font-semibold">Fullstack development</span>, and{" "}
              <span className="font-semibold">game designing</span>. I also – on the side – do a lot of{" "}
              <span className="font-semibold">moderation</span> within certain communities and games. 
              My secondary love is <span className="font-semibold">UI and Web Development</span>.
            </p>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
