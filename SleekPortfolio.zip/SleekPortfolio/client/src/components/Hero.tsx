import { motion } from "framer-motion";
import { useState, useEffect } from "react";

export function Hero() {
  const [text, setText] = useState("");
  const fullText = "Desired777";
  const [isTypingComplete, setIsTypingComplete] = useState(false);

  useEffect(() => {
    // Add a delay before starting the typewriter
    const startDelay = setTimeout(() => {
      let currentIndex = 0;
      const typingInterval = setInterval(() => {
        if (currentIndex <= fullText.length) {
          setText(fullText.slice(0, currentIndex));
          currentIndex++;
        } else {
          setIsTypingComplete(true);
          clearInterval(typingInterval);
        }
      }, 150);

      return () => clearInterval(typingInterval);
    }, 500);

    return () => clearTimeout(startDelay);
  }, []);

  return (
    <section className="min-h-screen flex items-center justify-center px-4 pt-24">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-center max-w-4xl mx-auto"
      >
        <motion.h1
          className="text-6xl md:text-8xl font-bold text-foreground mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          data-testid="text-hero-title"
        >
          {text}
          {!isTypingComplete && (
            <span className="animate-pulse">|</span>
          )}
        </motion.h1>
        <motion.p
          className="text-xl md:text-2xl text-muted-foreground"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          data-testid="text-hero-subtitle"
        >
          Building digital experiences with precision and passion
        </motion.p>
      </motion.div>
    </section>
  );
}
