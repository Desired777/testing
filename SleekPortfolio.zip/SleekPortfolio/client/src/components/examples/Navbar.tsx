import { Navbar } from "../Navbar";
import { ThemeProvider } from "../ThemeProvider";

export default function NavbarExample() {
  return (
    <ThemeProvider>
      <div className="min-h-screen bg-background">
        <Navbar />
      </div>
    </ThemeProvider>
  );
}
