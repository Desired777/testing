import { Experience } from "../Experience";

export default function ExperienceExample() {
  return (
    <div className="bg-background">
      <Experience />
    </div>
  );
}
