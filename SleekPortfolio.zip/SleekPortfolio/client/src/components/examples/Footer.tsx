import { Footer } from "../Footer";

export default function FooterExample() {
  return (
    <div className="bg-background">
      <Footer />
    </div>
  );
}
