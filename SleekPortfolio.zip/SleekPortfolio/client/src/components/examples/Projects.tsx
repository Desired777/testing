import { Projects } from "../Projects";

export default function ProjectsExample() {
  return (
    <div className="bg-background">
      <Projects />
    </div>
  );
}
