import { Skills } from "../Skills";

export default function SkillsExample() {
  return (
    <div className="bg-background">
      <Skills />
    </div>
  );
}
