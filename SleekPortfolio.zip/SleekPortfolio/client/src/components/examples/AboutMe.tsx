import { AboutMe } from "../AboutMe";

export default function AboutMeExample() {
  return (
    <div className="bg-background">
      <AboutMe />
    </div>
  );
}
