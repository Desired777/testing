import { Contact } from "../Contact";

export default function ContactExample() {
  return (
    <div className="bg-background">
      <Contact />
    </div>
  );
}
