import { motion } from "framer-motion";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { LocationTime } from "./LocationTime";

export function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  return (
    <section id="contact" className="min-h-screen flex items-center justify-center px-4 py-20">
      <div className="max-w-2xl w-full">
        <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-12 text-center" data-testid="text-contact-heading">
          Get In Touch
        </h2>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="bg-card/50 backdrop-blur-xl border-2 border-white/30 rounded-2xl shadow-[0_0_100px_rgba(255,255,255,0.4),0_0_50px_rgba(255,255,255,0.3)] hover:shadow-[0_0_150px_rgba(255,255,255,0.6),0_0_80px_rgba(255,255,255,0.5)] hover:scale-[1.01] transition-all duration-500"
        >
          <div className="flex items-center gap-2 px-4 py-3 border-b border-white/10">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
          </div>
          <div className="p-8 md:p-12">
            <form 
              action="https://api.web3forms.com/submit" 
              method="POST" 
              id="form"
            >
            <input type="hidden" name="access_key" value="1a6dc7aa-9a8b-44eb-9707-ce40cc8aa422" />
            <input type="hidden" name="subject" value="New Submission from Web3Forms" />
            <input type="hidden" name="from_name" value="Desired777 Portfolio" />
            <input type="hidden" name="redirect" value="https://web3forms.com/success" />
            <input type="checkbox" name="botcheck" style={{ display: 'none' }} />
            
            <div className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-foreground mb-2">
                  Name
                </label>
                <input
                  type="text"
                  name="name"
                  id="name"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-3 bg-background/50 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring text-foreground transition-all"
                  data-testid="input-contact-name"
                />
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-foreground mb-2">
                  Email
                </label>
                <input
                  type="email"
                  name="email"
                  id="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-3 bg-background/50 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring text-foreground transition-all"
                  data-testid="input-contact-email"
                />
              </div>
              
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-foreground mb-2">
                  Message
                </label>
                <textarea
                  name="message"
                  id="message"
                  required
                  rows={5}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full px-4 py-3 bg-background/50 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring text-foreground resize-none transition-all"
                  data-testid="input-contact-message"
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full"
                size="lg"
                data-testid="button-contact-submit"
              >
                Submit Form
              </Button>
            </div>
            </form>
            
            <LocationTime />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
