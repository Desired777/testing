# Design Guidelines for Desired777 Portfolio

## Design Approach
**Apple-Inspired Minimalism**: Strictly black-and-white aesthetic with frosted-glass effects, subtle glows, and smooth animations throughout. Default dark mode with animated light/dark toggle.

## Color Palette

**Dark Mode (Default)**:
- Background: Pure black (#000000) with subtle gradients allowed
- Card Backgrounds: Frosted-glass effect (semi-transparent with blur)
- Text: Pure white (#FFFFFF)
- Accents: Subtle white glows and outlines
- Gradients: Black-to-dark-gray subtle transitions permitted

**Light Mode**:
- Background: Pure white (#FFFFFF)
- Card Backgrounds: Frosted-glass effect with light blur
- Text: Pure black (#000000)
- Accents: Subtle black/gray glows and outlines

## Typography
- **Primary Font**: SF Pro Display or SF Pro Text (Apple system fonts) or similar Apple-inspired alternatives (Inter, -apple-system)
- **Navbar**: Medium weight, clean spacing
- **Headings**: Bold, large, minimalist
- **Body Text**: Regular weight, excellent readability
- **Special Effect**: Typewriter animation on "Desired777" name in navbar

## Layout System
**Spacing**: Use consistent Tailwind units - primarily 4, 8, 12, 16, 20, 24 for polished, Apple-like spacing
**Containers**: Max-width containers with generous padding
**Sections**: Clear vertical rhythm with ample breathing room between sections

## Component Library

### Navbar
- Floating, fixed position with rounded corners (xl or 2xl)
- Subtle glow outline effect
- Full width with internal max-width container
- Links: About, Skills, Experience, Projects, Contact
- World icon logo next to website name "Desired777"
- Animated dark/light mode toggle
- Typewriter animation on name
- Smooth scroll navigation to sections
- All buttons fully functional with hover animations

### Hero Section
- Positioned ABOVE About Me section
- Clean, minimal design with centered content
- Smooth entrance animation (fade-in, slide-up)
- Prominent introduction with visual hierarchy

### Cards (About Me, Skills, Experience, Projects, Contact)
- Frosted-glass effect (backdrop-blur with semi-transparent background)
- Rounded corners (lg, xl, or 2xl consistently)
- Subtle glow outline on all cards
- Hover effects: enhanced glow, subtle float-up animation
- Polished internal spacing and padding
- Card entrance animations (staggered fade-in, slide-up)

### Skills Section
- Horizontal card display (responsive grid)
- Three animated cards with Apple emojis/icons:
  1. **Community Moderation** 👥
  2. **LUA & Fullstack Development** 💻
  3. **Game Development** 🎮
- Float-up animation on hover
- Icon + title + description layout
- Equal card heights and widths

### Experience Section
- **Timeline Format**: Vertical scroll-down layout
- Chronological cards with glowing outlines
- Each card: Year range + role + description
- Cards:
  1. 2022–2024 – Back-End & LUA Freelance
  2. 2023–2024 – Crunchy Orc – Employee
- Footer text: "Still learning, more to be added here soon."
- Smooth entrance animation as user scrolls

### Projects Section
- Frosted-glass cards in grid layout
- Projects:
  1. **Axiom Interactive**: "A new and upcoming development studio in Roblox."
  2. **This Portfolio**: "The website you are currently viewing."
- Subtle glow intensifies on hover
- Animated card entrances
- Black-and-white minimalist with gradients allowed

### Contact Section
- Frosted-glass rounded card with glow outline
- Web3Forms integration (exact code provided in requirements)
- Form fields: Name, Email, Message (textarea)
- Animated focus states on input fields
- Submit button with hover animation
- **Auto-detected User Info**: Display city, country, and real-time local clock (updating every second) below form

### Footer
- Simple, centered design
- Text: "Made with ❤️"
- Minimal padding, clean separation from content

## Animations & Interactions
- **Typewriter Effect**: Name in navbar
- **Card Entrances**: Fade-in + slide-up for all cards
- **Hover Effects**: Glow enhancement, float-up on cards
- **Smooth Scrolling**: Navigation clicks scroll smoothly to sections
- **Toggle Animation**: Dark/light mode switch with smooth transition
- **Field Focus**: Animated glow/outline on contact form inputs
- **Hero Animation**: Smooth entrance for hero content
- All animations subtle, Apple-inspired, and performant

## Responsive Design
- **Mobile**: Single column layout, stacked cards, hamburger menu if needed
- **Tablet**: 2-column grids where appropriate, adjusted spacing
- **Desktop**: Full multi-column layouts, optimal spacing
- Fully functional across Mac, Windows, Android, iOS
- Touch-friendly interactive elements
- Responsive typography scaling

## Special Features
- Fully functional smooth-scroll navigation
- All navbar links working and jumping to sections
- Dark/light mode toggle with persistent state
- Real-time local clock (city, country, time to seconds)
- Web3Forms contact submission with exact provided configuration
- World icon logo integration
- Apple emoji/icon usage for skills

## Design Principles
- **Minimalism**: Clean, uncluttered, purposeful
- **Consistency**: Rounded corners, glow outlines, frosted-glass throughout
- **Polish**: Smooth animations, perfect spacing, attention to detail
- **Functionality**: All buttons and links working, complete interactivity
- **Professionalism**: Apple-inspired aesthetic, high-quality execution
- **Casualness**: Straightforward, approachable content tone